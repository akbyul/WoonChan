import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class GFileMenu extends JMenu {
	private static final long serialVersionUID = 1L;
	
	
	public GFileMenu(String s) {
		super(s);
		this.add(new JMenuItem("New"));
		this.add(new JMenuItem("Save"));
		this.add(new JMenuItem("Exit"));
	}
	

}
