import javax.swing.JPanel;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class GPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private Vector<Point> vStart = new Vector<Point>();
	private Vector<Point> vEnd = new Vector<Point>();
	
	public GPanel() {
		
		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				Point startP = e.getPoint();
				vStart.add(startP);
			}
			
			public void mouseReleased(MouseEvent e) {
				Point endP = e.getPoint();
				vEnd.add(endP);
				
				repaint();
			}
		});
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		
		
		for(int i=0; i<vStart.size(); i++) {
			Point s = vStart.elementAt(i);
			Point e = vEnd.elementAt(i);
						
			
			g.drawLine((int)s.getX(), (int)s.getY(), (int)s.getX(), (int)e.getY());
			g.drawLine((int)s.getX(), (int)s.getY(), (int)e.getX(), (int)s.getY());
			g.drawLine((int)e.getX(), (int)e.getY(), (int)e.getX(), (int)s.getY());
			g.drawLine((int)e.getX(), (int)e.getY(), (int)s.getX(), (int)e.getY());
		}

	}
	

}
