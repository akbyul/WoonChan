import javax.swing.JToolBar;

import java.awt.Color;

import javax.swing.JButton;

public class GToolBar extends JToolBar {
	private static final long serialVersionUID = 1L;

	public GToolBar() {
		
		this.setFloatable(false);
		this.setBackground(Color.LIGHT_GRAY);
		this.add(new JButton("Rectangel"));
		this.add(new JButton("Oval"));
		this.add(new JButton("Line"));
		this.add(new JButton("Polygon"));
	}


}