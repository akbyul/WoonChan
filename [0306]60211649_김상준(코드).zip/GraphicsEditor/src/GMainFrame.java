import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JFrame;

public class GMainFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	
	private GMenuBar menuBar;	
	private GToolBar toolBar;	
	private GPanel panel;

	
	public GMainFrame() {
		
		this.setSize(400, 600);
		this.setTitle("GraphicsEditor");
		
		this.menuBar = new GMenuBar();
		this.setJMenuBar(this.menuBar);
		
		this.toolBar = new GToolBar();
		this.add(toolBar, BorderLayout.NORTH);
		
		this.panel = new GPanel();
		this.add(panel, BorderLayout.CENTER);
				

	}
	
	


}
