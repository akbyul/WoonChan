import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JToolBar;

public class GToolBar extends JToolBar {
	private static final long serialVersionUID = 1L;

	public enum EShape {
		eSelect("Select"), eRectangle("Rectangle"), eOval("Oval"), eLine("Line"), ePolygon("Polygon"); // object

		private String name;

		private EShape(String name) {
			this.name = name;
		}

		public String getName() {
			return this.name;
		}

	}

	private EShape eSelectedShape;
	private JRadioButton selectButton;
	public EShape GetESelectedShape() {
		return this.eSelectedShape;
	}
	public void resetESelectedShape() {
		this.eSelectedShape = null;
		selectButton.doClick();
		
	}

	public GToolBar() {
		super();
		ActionHandler actionHandler = new ActionHandler();
		ButtonGroup buttonGroup = new ButtonGroup();
		for (EShape eButtonShape : EShape.values()) {
			JRadioButton buttonShape = new JRadioButton(eButtonShape.getName());
			this.add(buttonShape);
			buttonShape.setActionCommand(eButtonShape.toString());
			buttonShape.addActionListener(actionHandler);
			buttonGroup.add(buttonShape);
		}
		this.selectButton = (JRadioButton) this.getComponent(EShape.eSelect.ordinal());
		selectButton.doClick();
		eSelectedShape = EShape.eSelect;
	}

	private class ActionHandler implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent event) {
			eSelectedShape = EShape.valueOf(event.getActionCommand());
		}

	}
}
