import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.JPanel;

public class GDrawingPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private enum EDrawingState {
		eIdle, eDrawing, eMoving, eResizing, eRotating
	}

	private EDrawingState eDrawingState;
	private Vector<Rectangle> shapes;
	private Rectangle currentShape;
	// association
	private GToolBar toolBar;

	public void setToolBar(GToolBar toolBar) {
		this.toolBar = toolBar;
	}

	public GDrawingPanel() {
		super();
		this.eDrawingState = EDrawingState.eIdle;
		this.shapes = new Vector<Rectangle>();
		this.currentShape = null;

		this.setBackground(Color.WHITE);

		MouseHandler mouseEventHandler = new MouseHandler();
		this.addMouseListener(mouseEventHandler);
		this.addMouseMotionListener(mouseEventHandler);
	}

	public void paint(Graphics graphics) { // �׸� ����: Graphics
		super.paint(graphics); // extends (replace�ϴ� ��쿡�� ���� �ʾƵ� �ȴ�.)
		for (Rectangle shape : this.shapes) {
			shape.draw(graphics);
		}
	}

	public Rectangle onShape(Point point) {
		for (Rectangle rectangle : shapes) {
			if (rectangle.onShape(point)) {
				return rectangle;
			}
		}
		return null;
	}

	private class Rectangle {
		private int x, y, w, h, diffX, diffY;

		public Rectangle(int x, int y, int w, int h) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
		}

		public boolean onShape(Point p) {
			if ((p.x > x && p.x < x + w) && (p.y > y && p.y < y + h)) {
				return true;
			}
			return false;
		}

		public void draw(Graphics graphics) {
			if (toolBar.GetESelectedShape() == GToolBar.EShape.eLine) {
				graphics.drawLine(x, y, w + x, h + y);
			} else if (toolBar.GetESelectedShape() == GToolBar.EShape.eRectangle) {
				graphics.drawRect(x, y, w, h);
			} else if (toolBar.GetESelectedShape() == GToolBar.EShape.eOval) {
				graphics.drawOval(x, y, w, h);
			} else if (toolBar.GetESelectedShape() == GToolBar.EShape.ePolygon) {
			}
		}

		public void reDraw(Graphics graphics) {
			graphics.drawRect(x, y, w, h);
		}

		public void setDimension(int x2, int y2) {
			w = x2 - x;
			h = y2 - y;
		}
	}

	public void prepareTransforming(int x, int y) {
		if (toolBar.GetESelectedShape() == GToolBar.EShape.eRectangle) {
			currentShape = new Rectangle(x, y, 0, 0);
		} else if (toolBar.GetESelectedShape() == GToolBar.EShape.eOval) {
			currentShape = new Rectangle(x, y, 0, 0);
		} else if (toolBar.GetESelectedShape() == GToolBar.EShape.eLine) {
			currentShape = new Rectangle(x, y, 0, 0);
		} else if (toolBar.GetESelectedShape() == GToolBar.EShape.ePolygon) {
			currentShape = new Rectangle(x, y, 0, 0);
		}
	}

	public void keepTransforming(int x, int y) {
		Graphics graphics = getGraphics();
		graphics.setXORMode(getBackground());
		if (toolBar.GetESelectedShape() == GToolBar.EShape.eRectangle) {
			currentShape.draw(graphics);
			currentShape.setDimension(x, y);
			currentShape.draw(graphics);
		} else if (toolBar.GetESelectedShape() == GToolBar.EShape.eOval) {
			currentShape.draw(graphics);
			currentShape.setDimension(x, y);
			currentShape.draw(graphics);
		} else if (toolBar.GetESelectedShape() == GToolBar.EShape.eLine) {
			currentShape.draw(graphics);
			currentShape.setDimension(x, y);
			currentShape.draw(graphics);
		}
	}

	public void finalizeTransforming(int x, int y) {
		shapes.add(currentShape);
		currentShape = null;
		eDrawingState = EDrawingState.eIdle;
		toolBar.resetESelectedShape();
	}

//	private class Transformer {
//		public void prepareTransforming() {
//			
//		}
//		public void keepTransforming() {
//			
//		}
//		public void finalizeTransforming() {
//			
//		}
//	}

	private class MouseHandler implements MouseListener, MouseMotionListener {

		private int x1;
		private int y1;
		private int w;
		private int h;

		@Override
		public void mouseMoved(MouseEvent e) {
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mousePressed(MouseEvent e) {

			if (eDrawingState == EDrawingState.eIdle) {
				if (toolBar.GetESelectedShape() == GToolBar.EShape.eSelect) {
					currentShape = onShape(e.getPoint());
					if (currentShape != null) {
						eDrawingState = EDrawingState.eMoving;
						currentShape.diffX = e.getX() - currentShape.x;
						currentShape.diffY = e.getY() - currentShape.y;
					} else {
						this.x1 = e.getX();
						this.y1 = e.getY();
					}
				} else {
					currentShape = new Rectangle(e.getX(), e.getY(), 0, 0);
					eDrawingState = EDrawingState.eDrawing;
				}
			}
		}

		@Override
		public void mouseDragged(MouseEvent e) {
			if (eDrawingState == EDrawingState.eDrawing) {
				keepTransforming(e.getX(), e.getY());
			} else if (eDrawingState == EDrawingState.eMoving) {
				Graphics graphics = getGraphics();
				graphics.setXORMode(getBackground());
				currentShape.reDraw(graphics);
				currentShape.x = e.getX() - currentShape.diffX;
				currentShape.y = e.getY() - currentShape.diffY;
				currentShape.reDraw(graphics);
//				currentShape.reDraw(getGraphics());
			} else {
				Graphics graphics = getGraphics();
				graphics.setXORMode(getBackground());
				graphics.drawRect(this.x1, this.y1, this.w, this.h);
				this.w = e.getX() - this.x1;
				this.h = e.getY() - this.y1;
				graphics.drawRect(this.x1, this.y1, this.w, this.h);
			}
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			if (eDrawingState == EDrawingState.eDrawing) {
				finalizeTransforming(e.getX(), e.getY());
			}
			if (eDrawingState == EDrawingState.eMoving) {
				eDrawingState = EDrawingState.eIdle;
			} else {
				Graphics graphics = getGraphics();
				graphics.setXORMode(getBackground());
				graphics.drawRect(this.x1, this.y1, this.w, this.h);
				this.x1 = 0;
				this.y1 = 0;
				this.h = 0;
				this.w = 0;
			}
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}

	}
}
