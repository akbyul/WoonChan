import java.awt.Color;
import java.awt.event.*;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;

public class GShape extends JRadioButton {
	private static final long serialVersionUID = 1L;
	
	
	public static int Tshape = 0;
	
	public JRadioButton Rectangel = new JRadioButton("Rectangel");
	public JRadioButton Oval = new JRadioButton("Oval");
	public JRadioButton Line = new JRadioButton("Line");
	public JRadioButton Polygon = new JRadioButton("Polygon");
	public static JComboBox<Color> colorComboBox;
	public static JComboBox<Float> strokeComboBox;

	

	public GShape() {
		
		ButtonGroup g = new ButtonGroup();
		
		g.add(Rectangel);
		g.add(Oval);
		g.add(Line);
		g.add(Polygon);
		
		Rectangel.addItemListener(new GListener());
		Oval.addItemListener(new GListener());
		Line.addItemListener(new GListener());
		Polygon.addItemListener(new GListener());
		
		colorComboBox = new JComboBox<Color>();
		strokeComboBox = new JComboBox<Float>();
		
		colorComboBox.addActionListener(new GListener());
		strokeComboBox.addActionListener(new GListener());

		colorComboBox.setModel(new DefaultComboBoxModel<Color>(new Color[] { Color.black, Color.red, Color.blue,
				Color.green, Color.yellow, Color.pink, Color.magenta }));

		strokeComboBox.setModel(new DefaultComboBoxModel<Float>(
				new Float[] {(float) 1, (float) 5, (float) 10, (float) 15, (float) 20, (float) 25 }));
		

		
	}
	
	public class GListener implements ItemListener, ActionListener {
		
		public void itemStateChanged(ItemEvent e) {
			if(e.getStateChange() == ItemEvent.DESELECTED) {
				return;
			}
			
			if(Rectangel.isSelected()) {
				Tshape = 1;
			}
			
			else if(Oval.isSelected()) {
				Tshape = 2;
			}
			
			else if(Line.isSelected()) {
				Tshape = 3;
			}
			
			else if(Polygon.isSelected()) {
				Tshape = 4;
			}
		}
	
		public void actionPerformed(ActionEvent e) {

			if (e.getSource().equals(colorComboBox)) {
				GPanel.colors = (Color) colorComboBox.getSelectedItem();
			}

			else if (e.getSource().equals(strokeComboBox)) {
				GPanel.stroke = (float) strokeComboBox.getSelectedItem();
			}

		}
	}

}