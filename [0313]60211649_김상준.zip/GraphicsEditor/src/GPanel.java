import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import java.lang.*;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

public class GPanel extends JPanel implements ActionListener, MouseListener, MouseMotionListener {
	private static final long serialVersionUID = 1L;
	
	Point firstPointer = new Point(0, 0);
	Point secondPointer = new Point(0, 0);

	private int Clicked = 0;
	int[] x = new int[100];
	int[] y = new int[100];
	int[] fillx = new int[100];
	int[] filly = new int[100];
	
	BufferedImage bufferedImage;
	
	public static Color colors = Color.black;
	public static Float stroke = (float) 1;
	

	int width;
	int height;
	int minPointx;
	int minPointy;
	
	public GPanel() {


		Dimension d = getPreferredSize();
		bufferedImage = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_ARGB);
		setImageBackground(bufferedImage);
	

		addMouseListener(this);
		addMouseMotionListener(this);

	}

	public void mousePressed(MouseEvent e) {

		firstPointer.setLocation(0, 0);
		secondPointer.setLocation(0, 0);

		firstPointer.setLocation(e.getX(), e.getY());
		
		System.out.println("mousePressed");

	}

	public void mouseReleased(MouseEvent e) {
		secondPointer.setLocation(e.getX(), e.getY());
		updatePaint();
		
		System.out.println("mouseReleased");
	}


	public Dimension getPreferredSize() {
		return new Dimension(500, 700);
	}

	public void updatePaint() {
		
		width = Math.abs(secondPointer.x - firstPointer.x);
		height = Math.abs(secondPointer.y - firstPointer.y);

		minPointx = Math.min(firstPointer.x, secondPointer.x);
		minPointy = Math.min(firstPointer.y, secondPointer.y);

		Graphics2D g = bufferedImage.createGraphics();

		switch (GShape.Tshape) {

		case (3):
			g.setColor(colors);
			g.setStroke(new BasicStroke(stroke));
			g.drawLine(firstPointer.x, firstPointer.y, secondPointer.x, secondPointer.y);


			break;

		case (1):
			g.setColor(colors);
			g.setStroke(new BasicStroke(stroke));
			g.drawRect(minPointx, minPointy, width, height);
	

			break;

		case (2):
			g.setColor(colors);
			g.setStroke(new BasicStroke(stroke));
			g.drawOval(minPointx, minPointy, width, height);
	
			break;
			
		case (4):
			g.setStroke(new BasicStroke(stroke));
			g.setColor(Color.WHITE);
			g.fillPolygon(fillx,filly,Clicked);
			g.setColor(colors);
			g.drawPolygon(x,y,Clicked);
		
			break;

			
		default:
			break;

		}

		g.dispose();
		
		repaint();
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(bufferedImage, 0, 0, null);

	}

	public void setImageBackground(BufferedImage bi) {
		this.bufferedImage = bi;
		Graphics2D g = bufferedImage.createGraphics();
		g.setColor(Color.white);
		g.fillRect(0, 0, 500, 700);
		g.dispose();
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		System.out.println("mouseDragged");
		
		width = Math.abs(secondPointer.x - firstPointer.x);
		height = Math.abs(secondPointer.y - firstPointer.y);

		minPointx = Math.min(firstPointer.x, secondPointer.x);
		minPointy = Math.min(firstPointer.y, secondPointer.y);
		
		
		
		 if (GShape.Tshape == 3) {

			Graphics g = getGraphics();
			
			
			g.drawLine(firstPointer.x, firstPointer.y, secondPointer.x, secondPointer.y);
			secondPointer.setLocation(e.getX(), e.getY());
			repaint();
			g.dispose();
		} else if (GShape.Tshape == 1) {

			Graphics g = getGraphics();
			g.setColor(colors);
			g.setXORMode(getBackground());
			
			g.drawRect(minPointx, minPointy, width, height);
			secondPointer.setLocation(e.getX(), e.getY());
			repaint();
			g.dispose();
		} else if (GShape.Tshape == 2) {

			Graphics g = getGraphics();
			g.setColor(colors);
			g.setXORMode(getBackground());
			
			g.drawOval(minPointx, minPointy, width, height);
			secondPointer.setLocation(e.getX(), e.getY());
			
			g.dispose();
			repaint();
		}
		
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (GShape.Tshape == 4) {
			Graphics g = getGraphics();
			g.setColor(colors);
			((Graphics2D) g).setStroke(new BasicStroke(stroke));
			
			Clicked = Clicked+1;

			x[Clicked-1] = (int)(firstPointer.getX());
			y[Clicked-1] = (int) firstPointer.getY();
			fillx[Clicked-1] = (int)(firstPointer.getX()-1);
			filly[Clicked-1] = (int)(firstPointer.getY()-1);
			
			System.out.println("mouseClicked");
			
			updatePaint();
			
			if(e.getClickCount()>1) {
               
                Clicked = 0;
         }

			

		}

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}

