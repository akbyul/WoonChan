import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.BoxLayout;
import javax.swing.JFrame;

public class GMainFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	
	private GMenuBar menuBar;	
	private GToolBar toolBar;	
	public GPanel panel;

	
	public GMainFrame() {
		
		this.setSize(400, 600);
		this.setTitle("GraphicsEditor");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		//LayoutManager layoutManager = new FlowLayout();
		//LayoutManager layoutManager = new CardLayout();
		//LayoutManager layoutManager = new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS);
		//this.setLayout(layoutManager);
		
		this.menuBar = new GMenuBar();
		this.setJMenuBar(this.menuBar);
		
		this.toolBar = new GToolBar();
		this.add(toolBar, BorderLayout.NORTH);
		
		this.panel = new GPanel();
		this.add(panel, BorderLayout.CENTER);
				

	}
	
	


}
