package shapetools;

import java.awt.Graphics;
import java.awt.Graphics2D;

public class GRectangleTool extends GShapeTool {
	private int x1, y1, x2, y2, ox2, oy2;
	
	public GRectangleTool() {
		this.x1 = 0;
		this.y1 = 0;
		this.x2 = 0;
		this.y2 = 0;
		this.ox2 = 0;
		this.oy2 = 0;
		
	}
	
	public void setP1 (int x1, int y1) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x1;
		this.y2 = y1;
	}
	
	public void setP2 (int x2, int y2) {
		this.ox2 = this.x2;
		this.oy2 = this.y2;
		this.x2 = x2;
		this.y2 = y2;
	}
	

	@Override
	public void draw(Graphics graphics) {
//		Graphics2D graphics2D = (Graphics2D) graphics;
//		graphics2D.setXORMode(graphics2D.getBackground());
		
//		graphics2D.drawRect(x1, y1, ox2-x1, oy2-y1);
//		graphics2D.drawRect(x1, y1, x2-x1, y2-y1);
		graphics.drawRect(x1, y1, ox2-x1, oy2-y1);
		graphics.drawRect(x1, y1, x2-x1, y2-y1);
	}

	


}
