package shapetools;

import java.awt.Graphics;

public abstract class GShapeTool {
	public abstract void draw(Graphics graphics);
	public abstract void setP1 (int x1, int y1);
	
	public abstract void setP2 (int x2, int y2);
	
}

