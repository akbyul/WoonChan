package global;

import shapetools.GShapeTool;
import shapetools.GOval;
import shapetools.GRectangleTool;

public class Constants {

	public enum EShapeButtons{
		eRectangle("rectangle", new GRectangleTool()),
		eOval("oval", new GOval()),
		eLine("line", new GRectangleTool()),
		ePolygon("polygon", new GRectangleTool());
		
		
		private String text;
		private GShapeTool shapetool;
		EShapeButtons(String string, GShapeTool gShape) {
			this.text = string;
			this.shapetool = gShape;
		}
		public String getText(){return this.text;}
		public GShapeTool getShapeTool() {return this.shapetool;}
		
	}

}
