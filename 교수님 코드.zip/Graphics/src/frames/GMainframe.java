package frames;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

import global.Constants.EShapeButtons;

public class GMainframe extends JFrame{
	private static final long serialVersionUID = 1L;
	
	private GMenubar menuBar;
	private GToolBar shapeToolBar;
	private GDrawingPanel drawingPanel;

	public GMainframe() {
		this.setLocation(200,400);
		this.setSize(400,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Set Layout Manager
		// LayoutManager layoutmanager = new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS);
		// LayoutManager layoutmanager = new FlowLayout();
		// LayoutManager layoutmanager = new CardLayout();
		LayoutManager layoutmanager = new BorderLayout();


		this.setLayout(layoutmanager);
		
		
		// Set Menubar
		this.menuBar = new GMenubar();
		ShapeActionHandler shapeActionHandler = new ShapeActionHandler();
		this.shapeToolBar = new GToolBar(shapeActionHandler);
		this.drawingPanel = new GDrawingPanel();
		
		this.setJMenuBar(this.menuBar);
		this.add(shapeToolBar,BorderLayout.NORTH);
		this.add(drawingPanel,BorderLayout.CENTER);
		
		
				
		this.setVisible(true);
	}
	
	public class ShapeActionHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
		EShapeButtons eShapeButton = EShapeButtons.valueOf(e.getActionCommand());
		drawingPanel.setShapeTool(eShapeButton.getShapeTool());
		System.out.println(e.getActionCommand());
			
		}
	
	}
}
