package frames;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;

import shapetools.GShapeTool;


public class GDrawingPanel extends JPanel {
	private static final long serialVersionUID = 1L;


	private String shapeText;



	private GShapeTool shapeTool;
	
	


	public GDrawingPanel() {
//		this.setBackground(Color.green);
		MouseEventHandler mouseEventHandler = new MouseEventHandler();
		this.addMouseListener(mouseEventHandler);
		this.addMouseMotionListener(mouseEventHandler);
	}
	
	public void paint(Graphics graphics) {
		super.paint(graphics);
	}	
	
	private class MouseEventHandler implements MouseListener, MouseMotionListener{

		@Override
		public void mouseDragged(MouseEvent e) {
//			 System.out.println(new Object(){}.getClass().getEnclosingMethod().getName());
			shapeTool.setP2(e.getX(), e.getY());
			 shapeTool.draw(getGraphics());
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			 System.out.println(new Object(){}.getClass().getEnclosingMethod().getName());
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			System.out.println(new Object(){}.getClass().getEnclosingMethod().getName());
			shapeTool.setP1(e.getX(), e.getY());
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			 System.out.println(new Object(){}.getClass().getEnclosingMethod().getName());
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	


	
	
	
	
	

	


	public void setShape(String shapeText) {
		this.shapeText = shapeText;
		// TODO Auto-generated method stub
		
	}

	public void setShapeTool(GShapeTool shapeTool) {
		this.shapeTool = shapeTool;		
	}
	
}
