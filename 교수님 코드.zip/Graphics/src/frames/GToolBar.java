package frames;

import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JToolBar;

import frames.GMainframe.ShapeActionHandler;
import global.Constants.EShapeButtons;

public class GToolBar extends JToolBar{
	


	private static final long serialVersionUID = 1L;
	
	public GToolBar(GMainframe.ShapeActionHandler shapeActionHandler) {
		ButtonGroup buttonGroup = new ButtonGroup();
		for(EShapeButtons eShapeButtons : EShapeButtons.values() ) {
			JRadioButton button =  new JRadioButton(eShapeButtons.getText());
			this.add(button);
			button.setActionCommand(eShapeButtons.toString());
			button.addActionListener(shapeActionHandler);
			buttonGroup.add(button);
		}		
	}

}
