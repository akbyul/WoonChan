package main;

import frames.GMainframe;

public class GMain {
	
	public GMain() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GMainframe mainFrame = new GMainframe();
			
		mainFrame.setVisible(true);
	}

}
