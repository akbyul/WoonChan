import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class GMainFrame extends JFrame {
	
	private MyPanel panel = new MyPanel();
	
	public static void main(String[] args) {
		new GMain();
	}
	
	public GMainFrame() {
		this.setLocation(200, 100);
		this.setSize(400, 600);
		this.setContentPane(panel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	

	
	class MyPanel extends JPanel {
		private Vector<Point> vStart = new Vector<Point>();
		private Vector<Point> vEnd = new Vector<Point>();
		
		public MyPanel( ) {
			addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					Point startP = e.getPoint();
					vStart.add(startP);
				}
				
				public void mouseReleased(MouseEvent e) {
					Point endP = e.getPoint();
					vEnd.add(endP);
					
					repaint();
				}
			});
		}
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setColor(Color.BLACK);
			
			for(int i=0; i<vStart.size(); i++) {
				Point s = vStart.elementAt(i);
				Point e = vEnd.elementAt(i);
				
				g.drawRect((int)s.getX(), (int)s.getY(), (Math.abs((int)e.getX()-(int)s.getX())),(Math.abs((int)s.getY()-(int)e.getY())));
			}
	
		}
	}
}
