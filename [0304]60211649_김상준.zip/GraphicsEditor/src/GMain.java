import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class GMain {
	
	public GMain() {
		// TODO Auto-generated method stub
	}
	public static void main(String[] args) {
		GMainFrame mainFrame = new GMainFrame();
		mainFrame.setVisible(true);
	}

}