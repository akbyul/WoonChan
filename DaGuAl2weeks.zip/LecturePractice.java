
public class LecturePractice {
	private int[] rdata = {10,20,30,40,50,60};
	private int[] sdata = {10,15,20,25,30,35};
	
	
	public LecturePractice() {		
		// 파보나치 Iter & Recursion
		System.out.println(fiboIter(5));
		System.out.println(fiboRecursion(5));
		
		// 순차 검색 
		System.out.println(SeqSearch1(rdata,30));
		System.out.println(SeqSearch2(sdata,25));
		
		// 이진 검색
		System.out.println(BinarySearch(sdata,25,0,sdata.length));
	}

	public int fiboRecursion(int input) {
		if(input < 2) { return 1; }
		else { return fiboRecursion(input - 1) + fiboRecursion(input - 2); }
	}
	
	public int fiboIter(int input) {
		int[] val = new int[input+1];
		val[0]=1; val[1]=1;
		for(int i=2;i<=input;i++) {	val[i] = val[i-1]+val[i-2];	}
		return val[input];		
	}
	
	// Seq 방식 - 정렬되어있지 않은 자료용 
	public int SeqSearch1(int[] index, int key) {
		int n = index.length;
		for(int currentPointer =0; currentPointer<n; currentPointer++) {
			if(index[currentPointer]==key) {return currentPointer;}			
		}
		return -1;
	}
	
	// Seq 방식 - 정렬되어있는 자료용
	public int SeqSearch2(int[] index, int key) {	
		int currentPointer = 0;
		while(currentPointer<index.length && index[currentPointer]<key) {
			currentPointer++;
		}
		if(index[currentPointer] == key) {return currentPointer;}
		else {return -1;}		
	}
	
	private int BinarySearch(int[] input, int key, int start, int end) {
		// base condition
		if(start > end) {return -1;}		
		int mid = (start+end)/2;		
		if(input[mid] == key) {return mid;} // mid가 key과 같을 때
		else if(input[mid] < key) {return BinarySearch(input,key,start,mid-1);} // mid가 key보다 작을 때 
		else {return BinarySearch(input,key,mid+1,end);} // mid가 key보다 클 때
		
		// Recursion을 통해서 검색범위를 점점 줄여냐가는 원리. LogN의 관계로 성능이 뛰어남.
	}

}
