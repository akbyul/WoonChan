package menus;

import javax.swing.JMenu;

public class GFileMenu extends JMenu {

	public GFileMenu(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

}
