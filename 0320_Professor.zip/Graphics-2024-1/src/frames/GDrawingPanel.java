package frames;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

import shapetools.GDrawingTool;

public class GDrawingPanel extends JPanel {
	
	private enum EDrawingState {
		eIdle, eDrawing, eMoving, eResizing, eRotating
	}
	

	private EDrawingState eDrawingState;



	private String shapeText;



	private GDrawingTool shapeTool;
	
	

	private static final long serialVersionUID = 1L;
	public GDrawingPanel() {
		this.setBackground(Color.green);
	}
	
	public void paint(Graphics graphics) {
			
	}	
	private void draw(int x, int y) {
		this.shapeTool.draw(getGraphics(), x, y, x, y);
	}
	
	// EnumClass Getter Setter

	public EDrawingState geteDrawingState() {
		return eDrawingState;
	}

	public void seteDrawingState(EDrawingState eDrawingState) {
		this.eDrawingState = eDrawingState;
	}

	public void setShape(String shapeText) {
		this.shapeText = shapeText;
		// TODO Auto-generated method stub
		
	}

	public void setShapeTool(GDrawingTool shapeTool) {
		this.shapeTool = shapeTool;		
	}
	
}
