package main;

import frames.GMainframe;

public class GMain {
	
	public GMain() {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GMainframe mainFrame = new GMainframe();
		// OOP 문법은 항상 명사.동사	
		mainFrame.setVisible(true);
	}

}
