package shapetools;

import java.awt.Graphics;

public abstract class GDrawingTool {
	public abstract void draw(Graphics graphics, int x, int y, int w, int h);	

}
