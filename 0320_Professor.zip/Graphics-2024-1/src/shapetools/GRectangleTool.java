package shapetools;

import java.awt.Graphics;

public class GRectangleTool extends GDrawingTool {

	@Override
	public void draw(Graphics graphics, int x, int y, int w, int h) {
		// TODO Auto-generated method stub
		
	}

}
