package global;

import shapetools.GDrawingTool;
import shapetools.GRectangleTool;

public class Constants {

	public enum EShapeButtons{
		eRectangle("rectangle", new GRectangleTool()),
		eOval("oval", new GRectangleTool()),
		eLine("line", new GRectangleTool()),
		ePolygon("polygon", new GRectangleTool());
		
		// 서수이자 객체임.
		// 이미 new 되어있음
		// static임
		
		private String text;
		private GDrawingTool shapetool;
		EShapeButtons(String string, GDrawingTool gShape) {
			this.text = string;
			this.shapetool = gShape;
		}
		public String getText(){return this.text;}
		public GDrawingTool getShapeTool() {return this.shapetool;}
		
	}

}
