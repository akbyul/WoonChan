package global;

public class GOvalTool {

}
