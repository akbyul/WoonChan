import java.io.*;
import java.util.Scanner;
public class GradesCount {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		int A = 0;
		int B = 0;
		int C = 0;
		int D = 0;
		int F = 0;
		
		int A_list[] = new int[100];
		int Total = 0;
		int highest = 0;
		int list_count = 0;
		
		System.out.print("Enter grades(-1 to quit)");
		System.out.println();
		
		while (true)
		{
			int grade = scanner.nextInt();
			if ((grade >= 90) && (grade <= 100))
			{
				A += 1;
				A_list[list_count] = grade;
				Total += 1;
				
			}
			
			if ((grade >= 80) && (grade < 90))
			{
				B += 1;
				Total += 1;
			}
			
			if ((grade >= 70) && (grade < 80))
			{
				C += 1;
				Total += 1;
			}
			
			if ((grade >= 60) && (grade < 70))
			{
				D += 1;
				Total += 1;
			}
			
			if ((grade >= 0) && (grade < 60))
			{
				F += 1;
				Total += 1;
			}
			
			if (grade > highest)
			{
				highest = grade;
			}
			
			if (grade == -1)
			{
				break;
			}
			
			 list_count += 1;
				
		}
		scanner.close();
		System.out.println();
		System.out.println("<Results>");
		System.out.println("Total number of grades = " + Total);
		System.out.println("Number of A = " + A);
		System.out.println("Number of B = " + B);
		System.out.println("Number of C = " + C);
		System.out.println("Number of D = " + D);
		System.out.println("Number of F = " + F);
		System.out.println("The A grades are: " + A_list[0] +","+ A_list[1]);
		System.out.println("The highest score is: " + highest);

	}

}
