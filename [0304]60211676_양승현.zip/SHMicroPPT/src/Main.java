
public class Main {
	private static String	title = new String("SH MicroPPT");

	public static void main(String[] args) {
		// new mainFrame object
		SHMainFrame	mainFrame = new SHMainFrame(title);
		
	}

}
