import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.PointerInfo;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import Controller.IMenuPanelController;

class DrawModeVar {
	static boolean		isDrawMode = false;
	static PointerInfo	startPoint;
	static PointerInfo	endPoint;

}

public class SHDrawPanel extends JPanel{
	ImageIcon	IRectangle = new ImageIcon("./image/rectangle.jpg");
	
	private JButton	drawRectangle;
	
	public SHDrawPanel() {
		this.setBackground(Color.white);
		this.setLayout(new FlowLayout());
		
		this.drawRectangle = new JButton(IRectangle);
		this.drawRectangle.setSize(IRectangle.getIconWidth(), IRectangle.getIconHeight());
		this.drawRectangle.setBorderPainted(false);
		this.drawRectangle.setContentAreaFilled(false);
		
		this.add(drawRectangle);
		setDrawButtonEvent();
	}
	
	public static boolean		getIsDrawMode() { return (DrawModeVar.isDrawMode); }
	public static PointerInfo	getStartPoint() { return (DrawModeVar.startPoint); }
	public static PointerInfo	getendPoint() { return (DrawModeVar.endPoint); }
	
	public static void	setIsDrawMode(Boolean b) { DrawModeVar.isDrawMode = b; }
	public static void	setStartPoint(PointerInfo pt) { DrawModeVar.startPoint = pt; }
	public static void	setEndPoint(PointerInfo pt) { DrawModeVar.endPoint = pt; }

	public void setDrawButtonEvent() {
		
		this.drawRectangle.addMouseListener(new MouseAdapter() {
			
			@Override
			public void	mouseClicked(MouseEvent e) {
				if (DrawModeVar.isDrawMode == false)
					DrawModeVar.isDrawMode = true;
				else
					DrawModeVar.isDrawMode = false;
			}
		});
		
		
	}


}
