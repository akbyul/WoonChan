package Controller;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public interface IMenuPanelController {
	public final ImageIcon	Ihome = new ImageIcon("./image/home.jpg");
	public final ImageIcon	InewOpen = new ImageIcon("./image/newOpen.jpg");
	
	public final JButton	homeButton = new JButton(Ihome);;
	public final JButton	newOpenButton = new JButton(InewOpen);;
}
