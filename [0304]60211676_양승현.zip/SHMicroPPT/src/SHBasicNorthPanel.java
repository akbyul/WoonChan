import java.awt.Color;
import java.awt.LayoutManager;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class SHBasicNorthPanel extends JPanel {

	public SHBasicNorthPanel() {
		
		this.setBackground(Color.darkGray);
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		SHDrawPanel	drawPanel = new SHDrawPanel();
		
		this.add(drawPanel);
	}

}
