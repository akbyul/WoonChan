import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Controller.IMenuPanelController;

public class SHMenuWestPanel extends JPanel implements IMenuPanelController {	
	
	public SHMenuWestPanel() {
		this.setBackground(Color.darkGray);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		SHLabel	emptyLine1 = new SHLabel(" ", 15.0f);
		SHLabel	emptyLine2 = new SHLabel(" ", 3.0f);
	
		SHLabel titleLabel = new SHLabel("     SH PPT", 20.0f);
		titleLabel.setForeground(Color.lightGray);
		titleLabel.setHorizontalAlignment(JLabel.CENTER);
				
		homeButton.setSize(Ihome.getIconWidth(), Ihome.getIconHeight());
		homeButton.setBorderPainted(false);
		homeButton.setContentAreaFilled(false);
		
		newOpenButton.setSize(InewOpen.getIconWidth(), InewOpen.getIconHeight());
		newOpenButton.setBorderPainted(false);
		newOpenButton.setContentAreaFilled(false);

		
		this.add(emptyLine1);
		this.add(titleLabel);
		this.add(emptyLine2);
		this.add(homeButton);
		this.add(newOpenButton);
	}

}
