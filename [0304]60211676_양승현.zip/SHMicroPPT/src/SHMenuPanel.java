import java.awt.BorderLayout;

import javax.swing.JPanel;

public class SHMenuPanel extends JPanel {
	
	public SHMenuPanel() {		
		// set layout
		this.setLayout(new BorderLayout());
		
		SHMenuWestPanel	westPanel = new SHMenuWestPanel();
		
		
		this.add(westPanel, BorderLayout.WEST);
		
	}
	
}
