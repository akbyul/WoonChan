import javax.swing.Icon;
import javax.swing.JLabel;

public class SHLabel extends JLabel {

	public SHLabel(String text, float fontSize) {
		this.setText(text);
		this.setFont(this.getFont().deriveFont(fontSize));
	}
	
	public SHLabel(String text, float fontSize, String str) {
		this.setText(text);
		this.setFont(this.getFont().deriveFont(fontSize));
		this.setHorizontalAlignment(JLabel.CENTER);
	}

}
