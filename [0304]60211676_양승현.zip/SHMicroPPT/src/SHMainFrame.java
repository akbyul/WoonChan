import javax.swing.JFrame;
import javax.swing.JPanel;

import Controller.IMenuPanelController;

import java.awt.Dimension;
import java.awt.MouseInfo;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

public class SHMainFrame extends JFrame implements IMenuPanelController {
	
	// Frame variables
	private Dimension	frameSize = new Dimension(16 * 100, 9 * 100);
	private int			x = 400, y = 200;
	
	// panel
	public static SHMenuPanel	menuPanel = new SHMenuPanel();
	public static SHBasicPanel	basicPanel = new SHBasicPanel();	

	public SHMainFrame(String title) {
		
		// set frame values
		this.setTitle(title);
		this.setSize(this.frameSize);
		this.setLocation(this.x, this.y);
		this.setResizable(false);		
		
		// add Panel on frame
		this.add(menuPanel);
		menuPanel.setVisible(true);
		this.setVisible(true);
		this.add(basicPanel);
		basicPanel.setVisible(false);
		
		setMenuButtonEvent();
//		setDrawButtonEvent();

	}
	
//	public static SHMainFrame getSHMainFrame() { return (this); }

	public void setMenuButtonEvent() {
		newOpenButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuPanel.setVisible(false);
				basicPanel.setVisible(true);
			}
		});
	}
	
}
