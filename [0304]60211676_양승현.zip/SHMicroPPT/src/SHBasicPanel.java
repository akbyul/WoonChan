import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.MouseInfo;
import java.awt.PointerInfo;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class SHBasicPanel extends JPanel {

	public static JPanel	centerPanel;
	public static Rectangle2D.Float rectangle;
		
	public SHBasicPanel() {
		// set BorderLayout
		this.setLayout(new BorderLayout());
		
		SHBasicNorthPanel	northPanel = new SHBasicNorthPanel();

		this.add(northPanel, BorderLayout.NORTH);
		

		this.centerPanel = new JPanel();
		this.add(this.centerPanel, BorderLayout.CENTER);
		this.add(new SHLabel("Sorry this page is fixing...", 20.0f, "center"));

		setDrawButtonEvent();
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.black);
		g.drawRect(600, 400, 400, 400);
		g.setColor(Color.blue);
		g.drawRect(200, 300, 200, 400);
		g.setColor(Color.red);
		g.drawRect(300, 150, 400, 100);
		if (this.rectangle != null) {
			g.drawRect((int)this.rectangle.getX(), (int)this.rectangle.getY(), (int)this.rectangle.getWidth(), (int)this.rectangle.getHeight());
			System.out.println("Repaint");
		}

	}
	
	public void setDrawButtonEvent() {
	
		this.centerPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (SHDrawPanel.getIsDrawMode() == true) {
					SHDrawPanel.setStartPoint(MouseInfo.getPointerInfo());
				}
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				if (SHDrawPanel.getIsDrawMode() == true) {
					SHDrawPanel.setEndPoint(MouseInfo.getPointerInfo());

					SHBasicPanel.rectangle = new Rectangle2D.Float(SHDrawPanel.getStartPoint().getLocation().x, SHDrawPanel.getStartPoint().getLocation().y, SHDrawPanel.getendPoint().getLocation().x - SHDrawPanel.getStartPoint().getLocation().x, SHDrawPanel.getendPoint().getLocation().y - SHDrawPanel.getStartPoint().getLocation().y);
					System.out.println("Draw");
					repaint();
				}
				
			}
			
		});
	}
}
