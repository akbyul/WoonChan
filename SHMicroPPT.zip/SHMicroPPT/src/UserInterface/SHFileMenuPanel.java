package UserInterface;

import javax.swing.JPanel;

public class SHFileMenuPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public SHFileMenuPanel() {

	}

}
