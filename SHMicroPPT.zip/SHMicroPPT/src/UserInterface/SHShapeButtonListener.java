package UserInterface;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SHShapeButtonListener implements ActionListener {
	private int	shapeType;
	
	
	public SHShapeButtonListener(int shapeType) {
		this.shapeType = shapeType;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		SHShapeToolBar.setShapeType(this.shapeType);
	}

}
