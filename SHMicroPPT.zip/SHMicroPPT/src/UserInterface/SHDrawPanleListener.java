package UserInterface;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class SHDrawPanleListener implements MouseListener, MouseMotionListener {
	private SHDrawingPanel	drawingPanel;
	
	public SHDrawPanleListener(SHDrawingPanel drawingPanel) {
		this.drawingPanel = drawingPanel;
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (SHShapeToolBar.getShapeType() != SHShapeToolBar.none) {
			SHDrawingPanel.setStartPoint(e.getPoint());
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (SHShapeToolBar.getShapeType() != SHShapeToolBar.none) {
			SHShapeToolBar.setShapeType(SHShapeToolBar.none);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {

	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (SHShapeToolBar.getShapeType() != SHShapeToolBar.none) {
			SHDrawingPanel.setEndPoint(e.getPoint());
			SHDrawingPanel.setIsDraw(true);
			this.drawingPanel.repaint();
		}		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
