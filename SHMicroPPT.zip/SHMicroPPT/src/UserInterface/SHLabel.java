package UserInterface;

import javax.swing.Icon;
import javax.swing.JLabel;

public class SHLabel extends JLabel {
	private static final long serialVersionUID = 1L;

	public SHLabel(String text, int horizontalAlignment, int fontSize) {
		super(text, horizontalAlignment);
		this.setFont(this.getFont().deriveFont(fontSize));
		// TODO Auto-generated constructor stub
	}

	public SHLabel(Icon image, int horizontalAlignment) {
		super(image, horizontalAlignment);
		// TODO Auto-generated constructor stub
	}

}
