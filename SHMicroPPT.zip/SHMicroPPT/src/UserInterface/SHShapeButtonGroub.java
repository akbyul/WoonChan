package UserInterface;

import javax.swing.ButtonGroup;

public class SHShapeButtonGroub extends ButtonGroup {
	private static final long serialVersionUID = 1L;

	public SHShapeButtonGroub() {
		// TODO Auto-generated constructor stub
	}

}
