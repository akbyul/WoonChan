package UserInterface;

public class Main {
	
	public static void main(String[] args) {
		SHMainFrame mainFrame = new SHMainFrame("SH MicroPPT");
		mainFrame.setVisible(true);
	}

}