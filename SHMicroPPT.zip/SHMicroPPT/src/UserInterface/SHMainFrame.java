package UserInterface;

import java.awt.BorderLayout;

import javax.swing.JFrame;

public class SHMainFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private SHFileMenuPanel	fileMenuPanel;
	
	private SHMenuBar		menuBar;
	private SHShapeToolBar	toolBar;
	private SHDrawingPanel	drawingPanel;
	
	private int	winSizeX = 16 * 100, winSizeY = 9 * 100;
	private int	winLocateX = 100, winLocateY = 100;

	
	public SHMainFrame(String title) {
		super(title);
		this.initMainframe();
		
		this.fileMenuPanel = new SHFileMenuPanel();
		
		this.menuBar = new SHMenuBar();
		this.toolBar = new SHShapeToolBar();
		this.drawingPanel = new SHDrawingPanel();
		
		// add component
		this.setJMenuBar(this.menuBar);
		this.add(toolBar, BorderLayout.NORTH);
		this.add(drawingPanel, BorderLayout.CENTER);
	}
	
	private void initMainframe () {
		this.setSize(winSizeX, winSizeY);
		this.setLocation(winLocateX, winLocateY);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout());
	}

}
