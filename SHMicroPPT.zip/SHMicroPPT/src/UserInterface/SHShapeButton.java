package UserInterface;

import javax.swing.Icon;
import javax.swing.JRadioButton;

public class SHShapeButton extends JRadioButton {
	private static final long serialVersionUID = 1L;
	
	private SHShapeButtonListener shapeButtonListener;
	
	
	public SHShapeButton(Icon icon, int shapeType) {
		super(icon);
		
		this.shapeButtonListener = new SHShapeButtonListener(shapeType);
		
		this.addActionListener(this.shapeButtonListener);
	}

}
