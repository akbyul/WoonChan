package UserInterface;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Polygon;

import javax.swing.JPanel;

public class SHDrawingPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private SHDrawPanleListener drawPanleListener;
	
	private static boolean	isDraw = false;
	private static Point	startPoint, endPoint;

	public SHDrawingPanel() {
		this.drawPanleListener = new SHDrawPanleListener(this);
		
		this.addMouseListener(drawPanleListener);
		this.addMouseMotionListener(drawPanleListener);
	}
	
	public static void	setIsDraw(boolean isDraw) { SHDrawingPanel.isDraw = isDraw; }
	public static void	setStartPoint(Point point) { SHDrawingPanel.startPoint = point; }
	public static void	setEndPoint(Point point) { SHDrawingPanel.endPoint = point; }
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		if (isDraw == true) {
			int x = (startPoint.x < endPoint.x ? startPoint.x : endPoint.x);
			int y = (startPoint.y < endPoint.y ? startPoint.y : endPoint.y);
			int	width = Math.abs(SHDrawingPanel.endPoint.x - SHDrawingPanel.startPoint.x);
			int height = Math.abs(SHDrawingPanel.endPoint.y - SHDrawingPanel.startPoint.y);
			
			switch (SHShapeToolBar.getShapeType()) {
				case (SHShapeToolBar.rectangle):
					g.drawRect(x, y, width, height);
					break ;
				case (SHShapeToolBar.oval):
					g.drawOval(x, y, width, height);
					break ;
				case (SHShapeToolBar.polygon):
					Polygon polygon = new Polygon();
					polygon.addPoint(endPoint.x - ((endPoint.x - startPoint.x) / 2), startPoint.y);
					polygon.addPoint(endPoint.x, endPoint.y);
					polygon.addPoint(startPoint.x, endPoint.y);
					g.drawPolygon(polygon);
					break ;
					
				default:
			}
			isDraw = false;
		}
	}

}
