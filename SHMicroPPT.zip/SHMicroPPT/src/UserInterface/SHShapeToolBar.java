package UserInterface;

import javax.swing.ImageIcon;
import javax.swing.JToolBar;

public class SHShapeToolBar extends JToolBar {
	private static final long serialVersionUID = 1L;
	
	private ImageIcon	IconRectangle = new ImageIcon("./image/rectangle.jpg");
	private ImageIcon	IconOval = new ImageIcon("./image/oval.jpg");
	private ImageIcon	IconTriangle = new ImageIcon("./image/triangle.jpg");
	
	private static int	shapeType = SHShapeToolBar.none;
	
	public final static int	none = 0;
	public final static int	rectangle = 1;
	public final static int	oval = 2;
	public final static int	polygon = 3;
	
	
	private SHShapeButtonGroub	shapeButtonGroub;
	
	private SHShapeButton	rectangleButton;
	private SHShapeButton	ovalButton;
	private SHShapeButton	triangleButton;

	
	public SHShapeToolBar() {
		this.initToolBar();
		this.shapeButtonGroub = new SHShapeButtonGroub();
		
		this.rectangleButton = new SHShapeButton(IconRectangle, SHShapeToolBar.rectangle);
		this.ovalButton = new SHShapeButton(IconOval, SHShapeToolBar.oval);
		this.triangleButton = new SHShapeButton(IconTriangle, SHShapeToolBar.polygon);
		
		this.shapeButtonGroub.add(this.rectangleButton);
		this.shapeButtonGroub.add(this.ovalButton);
		this.shapeButtonGroub.add(this.triangleButton);
		
		this.add(this.rectangleButton);
		this.add(this.ovalButton);
		this.add(this.triangleButton);
	}

	private void initToolBar() {
		this.setFloatable(false);
//		this.addSeparator();
	}
	
	public static void	setShapeType(int shapeType) { SHShapeToolBar.shapeType = shapeType; }
	public static int	getShapeType() { return (SHShapeToolBar.shapeType); }
}
