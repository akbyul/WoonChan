package UserInterface;

import java.awt.Color;
import javax.swing.JMenuBar;

public class SHMenuBar extends JMenuBar {
	private static final long serialVersionUID = 1L;
	
	private SHFileMenu	fileMenu;
	
	public SHMenuBar() {
		initMenuBar();
		
		
		this.fileMenu = new SHFileMenu(" 파일 ");
		
		this.add(this.fileMenu);
	}

	private void initMenuBar() {
		this.setBackground(Color.lightGray);
//		this.setBorderPainted(true);
//		this.setMargin(new Insets(100, 100, 100, 100));		
	}
}
