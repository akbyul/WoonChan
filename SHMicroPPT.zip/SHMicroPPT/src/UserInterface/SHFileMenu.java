package UserInterface;

import javax.swing.BorderFactory;
import javax.swing.JMenu;

public class SHFileMenu extends JMenu {
	private static final long serialVersionUID = 1L;
	
	private float	menuFontSize = 15.0f;
	
	public SHFileMenu(String s) {
		super(s);
		this.initFileMenu();
	}

	private void initFileMenu() {
		this.setFont(this.getFont().deriveFont(menuFontSize));
		this.setBorder(BorderFactory.createCompoundBorder(this.getBorder(), BorderFactory.createEmptyBorder(3, 0, 3, 0)));
//		this.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0), this.getBorder()));
//		this.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
//		this.setBackground(Color.white);
//		this.setBorderPainted(true);
//		this.setMargin(new Insets(100, 100, 100, 100));		
	}
}
